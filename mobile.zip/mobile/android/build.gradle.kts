allprojects {
    repositories {
        google()
        mavenCentral()
    }
}

// Tentukan direktori build kustom
val customBuildDir: File = rootProject.file("custom_build")
val newBuildDir: Directory = rootProject.layout.buildDirectory.dir(customBuildDir.path).get()

// Atur direktori build untuk root project
rootProject.layout.buildDirectory.set(newBuildDir)

// Atur direktori build untuk subproyek
subprojects {
    val subprojectBuildDir: Directory = newBuildDir.dir(project.name)
    layout.buildDirectory.set(subprojectBuildDir)
    
    // Hanya terapkan dependency evaluasi jika modul :app ada
    if (project.name != "app" && rootProject.subprojects.any { it.name == "app" }) {
        evaluationDependsOn(":app")
    }
}

// Tambahkan tugas clean secara manual jika tidak ada
tasks.register("clean", Delete::class) {
    delete(rootProject.layout.buildDirectory)
}
